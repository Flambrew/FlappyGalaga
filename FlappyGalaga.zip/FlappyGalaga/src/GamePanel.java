// Andrew Matherne
// HackBI

import java.awt.*;
import java.awt.image.*;
import javax.swing.*;
import javax.imageio.*;
import java.io.*;
import java.awt.event.*;
import java.lang.Math;

public class GamePanel extends JPanel implements KeyListener
{
   BufferedImage img = null;
   BufferedImage pil1 = null;
   BufferedImage pil3 = null;
   int xLocation;
   int yLocation;
   double xSpeed;
   double ySpeed;
   double xVel = 0;
   double yVel = 0;
   int jumpCount = 0;
   private boolean[] keys = new boolean[120]; 
   public boolean up; 
   public boolean down; 
   public boolean left; 
   public boolean right; 
   
   int xpillar1_Loc;
   double pillar1_Vel;
   int ypillar1_Loc;
   int xpillar2_Loc;
   double pillar2_Vel;
   int ypillar2_Loc;
   int xpillar3_Loc;
   double pillar3_Vel;
   int ypillar3_Loc;
   int xpillar4_Loc;
   double pillar4_Vel;
   int ypillar4_Loc;
   
   double speed1 = Math.random()*0.15 + 0.2;
   double speed2 = Math.random()*0.15 + 0.2;
   double speed3 = Math.random()*0.15 + 0.2;
   double speed4 = Math.random()*0.15 + 0.2;  
   
   int gameOverCT = 100;
   double myGameTimer = 0;
   double myGameTimer2 = myGameTimer / 60;
   
   GamePanel() {
      setBackground(Color.BLUE);
      xLocation = 10;
      yLocation = 10;
      xSpeed = 0.4;
      ySpeed = 0.4;
      try {
         img = ImageIO.read(new File("galagathing.png"));  // 29 height, 31 width
      } catch (IOException e) {
         System.out.println("did not find galagathing.png");
      }
      
      xpillar1_Loc = 675;
      ypillar1_Loc = 0;
      pillar1_Vel = -0.5;
      
      xpillar2_Loc = 775;
      ypillar2_Loc = 240;
      pillar2_Vel = -0.5;
      
      xpillar3_Loc = 875;
      ypillar3_Loc = 0;
      pillar3_Vel = -0.5;
      
      xpillar4_Loc = 975;
      ypillar4_Loc = 140;
      pillar4_Vel = -0.5;
   
   
      
      try {
         pil1 = ImageIO.read(new File("pillarBottomSmall.png"));
      } catch (IOException e) {
         System.out.println("did not find stupid.png");
      }
      try {
         pil3 = ImageIO.read(new File("pillarBottomTall.png"));
      } catch (IOException e) {
         System.out.println("did not find dumb.png");
      }
   
      
      this.addKeyListener(this);
   }
   
   @Override 
      public void paintComponent(Graphics g) {
      g.setColor(Color.BLACK);
      g.fillRect(0, 0, this.getWidth(), this.getHeight());
      g.drawImage(img, xLocation, yLocation, null);
      g.drawImage(pil1, xpillar1_Loc, ypillar1_Loc, null);
      g.drawImage(pil1, xpillar2_Loc, ypillar2_Loc, null);
      g.drawImage(pil3, xpillar3_Loc, ypillar3_Loc, null);
      g.drawImage(pil3, xpillar4_Loc, ypillar4_Loc, null);
      if (gameOverCT <= 0) {
         g.setColor(Color.WHITE);
         g.drawString("GAME OVER, YOU'VE BEEN WUMPED!", 50, 50);
      }
      if (gameOverCT > 0) {
         g.setColor(Color.WHITE);
         g.drawString((String)gameOverCT, 50, 50);
      }
   }

// This allows a jpanel to react to keylistener - will not work without this
   @Override
   public boolean isFocusTraversable() {
      return true;
   }
     // This code shows you how to get all of the information from
     // the keylistener. The best place to call it is from the 
     // keyPressed event.
     // You should change your code to react the way you want it to
      
   private void display() {
   
      down = true; 
      left = keys[KeyEvent.VK_A] || keys[KeyEvent.VK_LEFT]; 
      right = keys[KeyEvent.VK_D] || keys[KeyEvent.VK_RIGHT]; 
   
      if (down) {         
         yVel += ySpeed;
         yVel = clamp(yVel, -8.0, 8.0);
      }
      if (left) {         
         xVel -= xSpeed;  
         xVel = clamp(xVel, -8.0, 8.0);      
      }
      if (right) {
         xVel += xSpeed;
         xVel = clamp(xVel, -8.0, 8.0);
      }
   }
   
   @Override public void keyTyped(KeyEvent e) { 
   } 

   @Override public void keyPressed(KeyEvent e) { 
      keys[e.getKeyCode()] = true;
      if (e.getKeyCode() == KeyEvent.VK_W || e.getKeyCode() == KeyEvent.VK_UP || e.getKeyCode() == KeyEvent.VK_SPACE) {
         if (xLocation == 0) {
            yVel = -12;
            jumpCount = 5;
         }
         else if (jumpCount < 5) {            
            yVel = -12;
            jumpCount += 1;
         }
      }
   } 

   @Override public void keyReleased(KeyEvent e) { 
      keys[e.getKeyCode()] = false;
   }
      
   public void update() {
   
      myGameTimer += 1;
      display();
      xLocation += xVel;
      yLocation += yVel;
      if (yLocation + img.getHeight() > this.getHeight()) {
         yLocation = this.getHeight() - img.getHeight();
         yVel *= -1;
         jumpCount = 0;
      }
      else if (yLocation < 0) {
         yLocation = 0;
         yVel = 0;
      }
      if (xLocation + img.getWidth() > this.getWidth()) {
         xLocation = this.getWidth() - img.getWidth();
         xVel = 0;
      }
      else if (xLocation < 0) {
         xLocation = 0;
         xVel = 0;
      }
      xpillar1_Loc += pillar1_Vel;
      if (xpillar1_Loc < 10) {
         xpillar1_Loc = 675;
         pillar1_Vel -= speed1;
      }
      xpillar2_Loc += pillar2_Vel;
      if (xpillar2_Loc < 10) {
         xpillar2_Loc = 725;
         pillar2_Vel -= speed2;
      }
      xpillar3_Loc += pillar3_Vel;
      if (xpillar3_Loc < 10) {
         xpillar3_Loc = 775;
         pillar3_Vel -= speed3;
      }
      xpillar4_Loc += pillar4_Vel;
      if (xpillar4_Loc < 10) {
         xpillar4_Loc = 825;
         pillar4_Vel -= speed4;
      }
      System.out.println("Life: " + gameOverCT/* + ", Time Survived: " + myGameTimer2*/);
      
      checkCollision();
      
   }     
   public void checkCollision() {
      if (xLocation < xpillar1_Loc + 1 &&
         xLocation + 31 > xpillar1_Loc &&
         yLocation < ypillar1_Loc + 125 &&
         yLocation + 31 > ypillar1_Loc) {
         gameOverCT -= 1;
      }
      if (xLocation < xpillar2_Loc + 1 &&
         xLocation + 31 > xpillar2_Loc &&
         yLocation < ypillar2_Loc + 125 &&
         yLocation + 31 > ypillar2_Loc) {
         gameOverCT -= 1;
      }
      if (xLocation < xpillar3_Loc + 1 &&
         xLocation + 31 > xpillar3_Loc &&
         yLocation < ypillar3_Loc + 225 &&
         yLocation + 31 > ypillar3_Loc) {
         gameOverCT -= 1;
      }
      if (xLocation < xpillar4_Loc + 1 &&
         xLocation + 31 > xpillar4_Loc &&
         yLocation < ypillar4_Loc + 225 &&
         yLocation + 31 > ypillar4_Loc) {
         gameOverCT -= 1;
      }
   }
   
   public void render() {
      repaint();
   }
   public double clamp(double num, double min, double max) { 
      if (num > max) {
         return max; 
      } 
      else if (num < min) { 
         return min; 
      } 
      return num; 
   }   
}