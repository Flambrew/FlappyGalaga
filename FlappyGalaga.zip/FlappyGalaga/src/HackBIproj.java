// Andrew Matherne, Joe Lentini, Eli Crenshaw
// HackBI

import java.awt.*;
import java.awt.image.*;
import javax.swing.*;
import javax.imageio.*;
import java.io.*;


public class HackBIproj 
{
   public HackBIproj() {
   }
   public static void main(String[] args)
   {
      HackBIproj hackP = new HackBIproj();
      GameFrame gf = new GameFrame();
      hackP.run(gf);
   }   
   public void run(GameFrame gf) { 
      long time = System.nanoTime(); 
      long timer = System.currentTimeMillis(); 
      final double nanoSecond = 1000000000.0 / 60.0; 
      double change = 0; 
      int frames = 0; 
      int updates = 0;
      boolean isRunning = true;
      while (isRunning) { 
         long currentTime = System.nanoTime();
         change += (currentTime - time) / nanoSecond; 
         time = currentTime; 
         while (change > 0) { 
            update(gf); updates++; change--; 
         } 
         render(gf);           
      } 
   } 
   public void render(GameFrame gf) {
      gf.render();
   }
   public void update(GameFrame gf) {
      gf.update();
   }
}