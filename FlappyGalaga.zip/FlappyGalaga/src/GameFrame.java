import java.awt.*;
import java.awt.image.*;
import javax.swing.*;
import javax.imageio.*;
import java.io.*;
import java.awt.event.*;

public class GameFrame extends JFrame
{
   private JFrame frame;
   private GamePanel gp;
   
   GameFrame()
   {
      frame = new JFrame("Window");
      frame.setSize(675,400);
      frame.setLocationRelativeTo(null);
      frame.setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
   
      // Container content = frame.getContentPane();
      // content.setBackground(Color.BLACK);  
      
      gp = new GamePanel();
      
      frame.add(gp, BorderLayout.CENTER);
      // frame.pack();
      frame.setVisible(true);
   } 
   public void update(){
      gp.update();
   }
   public void render() {
      gp.render();
   }
}